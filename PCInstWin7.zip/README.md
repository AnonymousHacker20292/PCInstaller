Start the main.vbs or start.bat file to run the program.
Made using VBScript and Batch.